const OperationBuilder = require("./OperationBuilder");

const {
    ENTITY_TYPE,
    TABLES,
    OPERATION_TYPE,
    CONFLICT_KEYS,
    ALTER_ID_COLUMN,
    VOUCHER_RECONCILIATION
} = require("./constants");


/*
function buildDeleteOperations({

    company_code,

    tally_owner,

    sync_batch_id,

    voucherGuids

}) {

    return [

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.VOUCHER_LEDGERS,

            operation: OPERATION_TYPE.DELETE,

            filters: [

                {

                    type: "in",

                    column: "voucher_guid",

                    value: voucherGuids

                }

            ],

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.VOUCHER_INVENTORY,

            operation: OPERATION_TYPE.DELETE,

            filters: [

                {

                    type: "in",

                    column: "voucher_guid",

                    value: voucherGuids

                }

            ],

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.STOCK_VOUCHERS,

            operation: OPERATION_TYPE.DELETE,

            filters: [

                {

                    type: "in",

                    column: "voucher_guid",

                    value: voucherGuids

                }

            ],

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.BILL_ALLOCATIONS,

            operation: OPERATION_TYPE.DELETE,

            filters: [

                {

                    type: "in",

                    column: "voucher_guid",

                    value: voucherGuids

                }

            ],

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.COST_CENTRE_ALLOCATIONS,

            operation: OPERATION_TYPE.DELETE,

            filters: [

                {

                    type: "in",

                    column: "voucher_guid",

                    value: voucherGuids

                }

            ],

            company_code,

            tally_owner,

            sync_batch_id

        })

    ];

}
*/

function buildDeleteOperations({
    company_code,
    tally_owner,
    sync_batch_id,
    voucherGuids
}) {

    const operations = [];

    const childTables =
        Object.entries(
            VOUCHER_RECONCILIATION.CHILDREN
        );

    for (const [table, config] of childTables) {

        operations.push(

            OperationBuilder.build({

                entity:
                    ENTITY_TYPE.VOUCHER,

                table,

                operation:
                    OPERATION_TYPE.DELETE,

                filters: [

                            {
                                type: "eq",

                                column: "company_code",

                                value: company_code

                            },

                            {
                                type: "eq",

                                column: "tally_owner",

                                value: tally_owner

                            },

                            {
                                type: "in",

                                column:
                                    config.guidColumn,

                                value:
                                    voucherGuids
                            }

                        ],

                company_code,

                tally_owner,

                sync_batch_id

            })

        );

    }

    return operations;
}

function buildSaveOperations({

    company_code,

    tally_owner,

    sync_batch_id,

    voucherRows,

    ledgerRows,

    inventoryRows,

    stockVoucherRows,

    billAllocationRows,

    costCentreRows

}) {

    return [

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.VOUCHERS,

            operation: OPERATION_TYPE.UPSERT,

            rows: voucherRows,

           options: {

                onConflict:
                    CONFLICT_KEYS[TABLES.VOUCHERS]

            },

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.VOUCHER_LEDGERS,

            operation: OPERATION_TYPE.INSERT,

            rows: ledgerRows,

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.VOUCHER_INVENTORY,

            operation: OPERATION_TYPE.INSERT,

            rows: inventoryRows,

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.STOCK_VOUCHERS,

            operation: OPERATION_TYPE.INSERT,

            rows: stockVoucherRows,

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.BILL_ALLOCATIONS,

            operation: OPERATION_TYPE.INSERT,

            rows: billAllocationRows,

            company_code,

            tally_owner,

            sync_batch_id

        }),

        OperationBuilder.build({

            entity: ENTITY_TYPE.VOUCHER,

            table: TABLES.COST_CENTRE_ALLOCATIONS,

            operation: OPERATION_TYPE.INSERT,

            rows: costCentreRows,

            company_code,

            tally_owner,

            sync_batch_id

        })

    ];

}

function buildOperation(args) {

    return buildVoucherOperations(

        args

    );

}

function buildVoucherOperations(args) {

    return [

        ...buildDeleteOperations(args),

        ...buildSaveOperations(args)

    ];

}


function buildAlterUpdateOperations({
    table,
    company_code,
    tally_owner,
    sync_batch_id,
    alterChanged = []
}) {

    return alterChanged.map(item => ({
        entity: ENTITY_TYPE.VOUCHER,
        table: TABLES.VOUCHERS,
        operation: OPERATION_TYPE.UPDATE,

      values: {
                [ALTER_ID_COLUMN[TABLES.VOUCHERS]]:
                    item.newAlterId,

                sync_batch_id,

                updated_at:
                    new Date().toISOString()
            },

        filters: [
            {
                type: "eq",
                column: "company_code",
                value: company_code
            },
            {
                type: "eq",
                column: "tally_owner",
                value: tally_owner
            },
            {
                type: "eq",
                column: "guid",
                value: item.guid
            }
        ]
    }));
}

/* 080826

function buildSoftDeleteOperations({
    table,
    company_code,
    tally_owner,
    sync_batch_id,
    extraGuids = []
}) {

    return extraGuids.map(item => ({
        entity: ENTITY_TYPE.VOUCHER,
        table: TABLES.VOUCHERS,
        operation: OPERATION_TYPE.UPDATE,

        values: {
            is_deleted: true,
            sync_batch_id,
            updated_at: new Date().toISOString()
        },

        filters: [
            {
                type: "eq",
                column: "company_code",
                value: company_code
            },
            {
                type: "eq",
                column: "tally_owner",
                value: tally_owner
            },
            {
                type: "eq",
                column: "guid",
                value: item.guid
            },
            {
                type: "eq",
                column: "is_deleted",
                value: false
            }
        ]
    }));
}
*/

function buildOrphanDeleteOperations({
    company_code,
    tally_owner,
    sync_batch_id,
    orphanGuids = {}
}) {

    const operations = [];

    for (
        const [childTable, voucherGuids]
        of Object.entries(orphanGuids)
    ) {

        if (
            !Array.isArray(voucherGuids) ||
            voucherGuids.length === 0
        ) {
            continue;
        }

        const childConfig =
            VOUCHER_RECONCILIATION
                .CHILDREN[childTable];

        if (!childConfig) {
            continue;
        }

        operations.push(

            OperationBuilder.build({

                entity:
                    ENTITY_TYPE.VOUCHER,

                table:
                    childTable,

                operation:
                    OPERATION_TYPE.DELETE,

                filters: [

                    {
                        type: "eq",
                        column: "company_code",
                        value: company_code
                    },

                    {
                        type: "eq",
                        column: "tally_owner",
                        value: tally_owner
                    },

                    {
                        type: "in",
                        column:
                            childConfig.guidColumn,
                        value:
                            voucherGuids
                    }

                ],

                company_code,
                tally_owner,
                sync_batch_id

            })

        );

    }

    return operations;
}

function buildSoftDeleteOperations({
    table,
    company_code,
    tally_owner,
    sync_batch_id,
    extraGuids = []
}) {

    const operations = [];

    for (const item of extraGuids) {

        const voucherGuid = item.guid;

        // --------------------------------------------------
        // 1. Child voucher rows → HARD DELETE
        // --------------------------------------------------

        operations.push(
            ...buildDeleteOperations({

                company_code,

                tally_owner,

                sync_batch_id,

                voucherGuids: [
                    voucherGuid
                ]

            })
        );

        // --------------------------------------------------
        // 2. Main voucher row → SOFT DELETE
        // --------------------------------------------------

        const root =
            VOUCHER_RECONCILIATION.ROOT;

        operations.push(

            OperationBuilder.build({

                entity:
                    ENTITY_TYPE.VOUCHER,

                table:
                    root.table,

                operation:
                    OPERATION_TYPE.UPDATE,

                values: {

                    [root.deletedColumn]:
                        true,

                    sync_batch_id,

                    [root.updatedColumn]:
                        new Date().toISOString()

                },

                filters: [

                    {
                        type: "eq",

                        column:
                            "company_code",

                        value:
                            company_code
                    },

                    {
                        type: "eq",

                        column:
                            "tally_owner",

                        value:
                            tally_owner
                    },

                    {
                        type: "eq",

                        column:
                            root.guidColumn,

                        value:
                            voucherGuid
                    },

                    {
                        type: "eq",

                        column:
                            root.deletedColumn,

                        value:
                            false
                    }

                ],

                company_code,

                tally_owner,

                sync_batch_id

            })

        );

    }

    return operations;
}


module.exports = {

    buildOperation,

    buildDeleteOperations,

    buildSaveOperations,

    buildVoucherOperations,

    buildAlterUpdateOperations,

    buildSoftDeleteOperations,

    buildOrphanDeleteOperations,

};